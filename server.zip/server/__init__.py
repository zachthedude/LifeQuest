"""LifeQuest server package."""
